const config = {
    secret_key: "cmpe_273_uber_eats",
    mongoDB: "mongodb+srv://dbUberEats:admin1234@ubereats.f2j2m.mongodb.net/dbUberEats?retryWrites=true&w=majority",
};

module.exports = config;